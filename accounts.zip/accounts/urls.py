from django.urls import path
from .views import SignUp,home
urlpatterns=[
    path('home/',home,name='home'),
    path('signup/',SignUp.as_view(),name='signup'),
]